package org.insbaixcamp.reservesapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        Button login = findViewById(R.id.b_login);
        Button register = findViewById(R.id.b_registre);
        Button skip = findViewById(R.id.b_omet);

        login.setOnClickListener(v -> {
/*                //Obtiene el Fragment manager
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            //agrega el Fragment en el contenedor, en este caso el FrameLayout con id `FrameLayout`.
            ft.add(R.id.fragment_inici_sesio, new SlideshowFragment());
            ft.commit();*/
            Bundle args = new Bundle();
            args.putBoolean("login",true);

            Intent intent = new Intent(MenuPrincipal.this, MainActivity.class);
            startActivity(intent);

/*            NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
        .findFragmentById(R.id.fragment_inici_sesio);
NavController navCo = navHostFragment.getNavController();*/

//                Navigation.findNavController(v).navigate(R.id.fragment_inici_sesio);

            //Navigation.findNavController(binding.getRoot()).navigate(R.id.nav_inici);
        });

        register.setOnClickListener(v -> {

            Bundle args = new Bundle();
            args.putBoolean("registre",true);

            Intent intent = new Intent(MenuPrincipal.this, MainActivity.class);
            startActivity(intent);
        });

        skip.setOnClickListener(v -> {
            Intent intent = new Intent(MenuPrincipal.this, MainActivity.class);
            startActivity(intent);
        });
    }
}