package org.insbaixcamp.reservesapp.ui.iniciar_sesio;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

import org.insbaixcamp.reservesapp.MainActivity;
import org.insbaixcamp.reservesapp.R;
import org.insbaixcamp.reservesapp.databinding.FragmentIniciSesioBinding;
import org.insbaixcamp.reservesapp.ui.inici.HomeFragment;
import org.jetbrains.annotations.NotNull;

import java.util.zip.Inflater;

public class SlideshowFragment extends Fragment {

    private FragmentIniciSesioBinding binding;
    private SlideshowViewModel slideshowViewModel;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGAuth;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                new ViewModelProvider(this).get(SlideshowViewModel.class);

        binding = FragmentIniciSesioBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        mAuth = FirebaseAuth.getInstance();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        Button login = binding.bLogin;
        Button loginGoogle = binding.bLogingoogle;
        EditText email = binding.etCorreu;
        EditText pass = binding.etContrasenya;

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String correu = email.getText().toString();
                String contra = pass.getText().toString();

                if (!correu.isEmpty() && !contra.isEmpty()){

                    mAuth.signInWithEmailAndPassword(correu,contra).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull @NotNull Task<AuthResult> task) {

                            if (task.isSuccessful()){

                                startActivity(new Intent(getActivity(), HomeFragment.class));
                                try {
                                    finalize();
                                } catch (Throwable throwable) {
                                    throwable.printStackTrace();
                                }

                            } else {
                                Toast.makeText(getContext(), "No s'ha pogut iniciar sesio", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                } else {

                    Toast.makeText(getContext(), "Omple tots el camps", Toast.LENGTH_SHORT).show();
                }

            }
        });

        loginGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        slideshowViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {

            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}