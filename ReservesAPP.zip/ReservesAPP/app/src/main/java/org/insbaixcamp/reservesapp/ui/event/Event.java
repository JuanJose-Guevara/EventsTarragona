package org.insbaixcamp.reservesapp.ui.event;

public class Event {

    String recinte;
    String adresa;

}
